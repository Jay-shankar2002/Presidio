from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

DATABASE = 'users.db'

def init_db():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                phone_number TEXT NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS properties (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                area INTEGER,
                bedrooms INTEGER,
                bathrooms INTEGER,
                address TEXT NOT NULL,
                hospitals_nearby TEXT,
                colleges_nearby TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        ''')
        conn.commit()

init_db()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    first_name = data['first_name']
    last_name = data['last_name']
    email = data['email']
    phone_number = data['phone_number']
    password = data['password']

    hashed_password = generate_password_hash(password, method='sha256')

    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO users (first_name, last_name, email, phone_number, password)
                VALUES (?, ?, ?, ?, ?)
            ''', (first_name, last_name, email, phone_number, hashed_password))
            conn.commit()
            return jsonify({'message': 'Registration successful'}), 201
        except sqlite3.IntegrityError:
            return jsonify({'message': 'Registration failed, email already exists'}), 400

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data['email']
    password = data['password']

    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()

        if user and check_password_hash(user[5], password):
            session['user_id'] = user[0]
            session['email'] = user[3]
            return jsonify({'message': 'Login successful'}), 200
        else:
            return jsonify({'message': 'Login failed'}), 401

@app.route('/main')
def main():
    if 'user_id' not in session:
        return redirect(url_for('home'))
    return render_template('main.html')

@app.route('/properties')
def view_properties():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT p.id, p.title, p.description, p.area, p.bedrooms, p.bathrooms, p.address, p.hospitals_nearby, p.colleges_nearby, u.first_name, u.last_name, u.email, u.phone_number FROM properties p JOIN users u ON p.user_id = u.id')
        properties = cursor.fetchall()
    return render_template('properties.html', properties=properties)

@app.route('/property/new', methods=['GET', 'POST'])
def new_property():
    if request.method == 'POST':
        data = request.form
        user_id = session.get('user_id')
        if not user_id:
            return redirect(url_for('login'))
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO properties (user_id, title, description, area, bedrooms, bathrooms, address, hospitals_nearby, colleges_nearby)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (user_id, data['title'], data.get('description'), data['area'], data['bedrooms'], data['bathrooms'], data['address'], data.get('hospitals_nearby'), data.get('colleges_nearby')))
            conn.commit()
        return redirect(url_for('view_properties'))
    return render_template('new_property.html')

@app.route('/property/<int:id>/edit', methods=['GET', 'POST'])
def edit_property(id):
    if request.method == 'POST':
        data = request.form
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE properties SET title = ?, description = ?, area = ?, bedrooms = ?, bathrooms = ?, address = ?, hospitals_nearby = ?, colleges_nearby = ?
                WHERE id = ?
            ''', (data['title'], data.get('description'), data['area'], data['bedrooms'], data['bathrooms'], data['address'], data.get('hospitals_nearby'), data.get('colleges_nearby'), id))
            conn.commit()
        return redirect(url_for('view_properties'))
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM properties WHERE id = ?', (id,))
        property = cursor.fetchone()
    return render_template('edit_property.html', property=property)

@app.route('/property/<int:id>/delete', methods=['POST'])
def delete_property(id):
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('DELETE FROM properties WHERE id = ?', (id,))
        conn.commit()
    return redirect(url_for('view_properties'))

if __name__ == '__main__':
    app.run(debug=True)
